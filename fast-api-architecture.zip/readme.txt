core yg perlu diinstall:
`pip install fastapi uvicorn pydantic[email]`

copas example.env jadi .env

command untuk run:
`python bin/main.py`

contoh curl:
>>> curl -H "X-API-Key: llllllavacccccchicken" "http://127.0.0.1:5000/v1/playwright?brand_name=samsung"

output: {"brand_name":"samsung","sentiments":["yeah","cool","anjass"]}